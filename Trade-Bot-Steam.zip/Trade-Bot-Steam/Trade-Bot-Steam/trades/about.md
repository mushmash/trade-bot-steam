### Trades folder
Inside of this folder you will see all the trades that you've done. This is still a working process and there are not much information about the trades in these files at the moment.