readValue('game', (data) => {
  console.log(data);
});